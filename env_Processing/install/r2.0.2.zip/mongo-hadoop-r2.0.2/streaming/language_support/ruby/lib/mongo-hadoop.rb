require 'mongo-hadoop/mapper'
require 'mongo-hadoop/reducer'