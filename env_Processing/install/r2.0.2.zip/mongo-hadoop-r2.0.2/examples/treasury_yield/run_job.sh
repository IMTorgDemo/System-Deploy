#!/bin/sh

echo "Run this job via gradle from the root directory:  ./gradlew historicalYield"