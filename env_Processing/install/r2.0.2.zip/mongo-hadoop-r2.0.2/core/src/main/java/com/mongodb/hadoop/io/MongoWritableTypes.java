package com.mongodb.hadoop.io;

// CHECKSTYLE:OFF
public interface MongoWritableTypes {
    int BSON_WRITABLE = 0;
    int MONGO_UPDATE_WRITABLE = 1;
}
// CHECKSTYLE:ON
