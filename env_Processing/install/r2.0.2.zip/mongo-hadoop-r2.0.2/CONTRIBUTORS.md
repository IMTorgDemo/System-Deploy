* Mike O'Brien (mikeo@10gen.com)
* Brendan McAdams brendan@10gen.com
* Eliot Horowitz erh@10gen.com
* Ryan Nitz ryan@10gen.com
* Russell Jurney (@rjurney) (Lots of significant Pig improvements)
* Sarthak Dudhara sarthak.83@gmail.com (BSONWritable comparable interface)
* Priya Manda priyakanth024@gmail.com (Test Harness Code)
* Rushin Shah rushin10@gmail.com (Test Harness Code)
* Joseph Shraibman jks@iname.com (Sharded Input Splits)
* Sumin Xia xiasumin1984@gmail.com (Sharded Input Splits)
* Jeremy Karn
* bpfoster
* Ross Lawley
* Carsten Hufe
* Asya Kamsky
* Thomas Millar
* Justin Lee
* Luke Lovett
* Mariano Semelman
* Jordan Gwyn
* Powerrr
